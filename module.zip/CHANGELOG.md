1.0

	First version. Please excuse any bugs or issues, as this is my first attempt at a Foundry module.