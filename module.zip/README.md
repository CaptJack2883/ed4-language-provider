# ed4-language-provider
Language provider for the Earthdawn 4th Edition game system for the Polyglot module for Foundry VTT